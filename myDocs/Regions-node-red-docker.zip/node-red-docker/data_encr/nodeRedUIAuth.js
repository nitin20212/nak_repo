const when = require('when')
const fileProcessUtility = require('./fileProcessUtility')

const getNodeRedUICredentials = (lineName) => {
  let userProp = lineName.split('_')[1]
  let userIndex = Number(lineName.split('_')[2]) - 1
  return {
    userProp,
    userIndex
  }
}

const getEnvironmentCredentials = () => {
  let nodeRedUsers = fileProcessUtility.getEnvironmentCredentialsArray().reduce((output, currentLine) => {
    let { lineName, lineEncryption, lineValue } = fileProcessUtility.extractLineVariable(currentLine)
    if (lineName.startsWith('nodeRedUI')) {
      let userInfo = getNodeRedUICredentials(lineName)
      if (output[userInfo.userIndex] === undefined) {
        output[userInfo.userIndex] = {}
      }
      lineValue = lineEncryption === 'Y' ? fileProcessUtility.decrypt(lineValue) : lineValue
      output[userInfo.userIndex][userInfo.userProp] = lineValue
    }
    return output
  }, [])
  return nodeRedUsers
}

const getAuthenticatedUser = (username, password = null) => {
  const nodeRedUsers = getEnvironmentCredentials()
  return nodeRedUsers.reduce((foundUser, currentUser) => {
    if (foundUser.length > 0) {
      return foundUser
    } else {
      if (currentUser.username === username) {
        if (currentUser.permissions !== undefined) {
          if (password === null) {
            let validatedUser = { username, permissions: currentUser.permissions }
            foundUser.push(validatedUser)
          } else if (password === currentUser.password) {
            let validatedUser = { username, permissions: currentUser.permissions }
            foundUser.push(validatedUser)
          }
        }
      }
      return foundUser
    }
  }, [])
}

module.exports = {
  type: 'credentials',
  users: function (username) {
    return when.promise(function (resolve) {
      let foundUser = getAuthenticatedUser(username)
      if (foundUser.length > 0) {
        resolve(foundUser[0])
      } else {
        resolve(null)
      }
    })
  },
  authenticate: function (username, password) {
    return when.promise(function (resolve) {
      let foundUser = getAuthenticatedUser(username, password)
      if (foundUser.length > 0) {
        resolve(foundUser[0])
      } else {
        resolve(null)
      }
    })
  },
  default: function () {
    return when.promise(function (resolve) {
      resolve(null)
    })
  }
}
