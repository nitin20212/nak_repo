const crypto = require('crypto-js')
const fs = require('fs')
const m_base_key_path = '/usr/src/node-red/keyfiles/'
const password_file = 'password_phrase.txt'
const environment_file = 'SOE_environment_file'
const password_phrase = fs.readFileSync(m_base_key_path + password_file, 'utf8')

const getEnvironmentCredentialsArray = () => {
  return fs.readFileSync(m_base_key_path + environment_file, 'utf8').split('\n').filter(line => line.split('|').length > 2)
}

const extractLineVariable = (line) => {
  let lineArray = line.split('|')
  let lineName = lineArray[0].trim()
  let lineEncryption = lineArray[1].trim()
  let lineValue = lineArray[2].trim()
  return {
    lineName,
    lineEncryption,
    lineValue
  }
}

const validatePassword = (passwordInput, userPassword) => {
  let decrypted = crypto.AES.decrypt(userPassword, password_phrase).toString(crypto.enc.Utf8)
  return decrypted === passwordInput
}

const decrypt = (userPassword) => {
  return crypto.AES.decrypt(userPassword, password_phrase).toString(crypto.enc.Utf8)
}

module.exports = {
  getEnvironmentCredentialsArray,
  extractLineVariable,
  validatePassword,
  decrypt
}
