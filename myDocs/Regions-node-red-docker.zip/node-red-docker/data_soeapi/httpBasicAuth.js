const auth = require('basic-auth')
const fileProcessUtility = require('./fileProcessUtility')

const getEnvironmentCredentials = () => {
  let environmentCredentials = fileProcessUtility.getEnvironmentCredentialsArray().reduce((output, currentLine) => {
    let { lineName, lineEncryption, lineValue } = fileProcessUtility.extractLineVariable(currentLine)
    if (lineName === 'httpNodeBasicAuthUsername' || lineName === 'httpNodeBasicAuthPassword') {
      output[lineName] = {
        value: lineValue,
        isEncrypted: lineEncryption
      }
    }
    return output
  }, {})
  return environmentCredentials
}
const getAuthenticatedUser = (username, password = null) => {
  let environmentCredentials = getEnvironmentCredentials()
  let foundUser = []
  if (environmentCredentials.httpNodeBasicAuthUsername.value === username) {
    if (environmentCredentials.httpNodeBasicAuthPassword.isEncrypted === 'Y') {
      if (fileProcessUtility.validatePassword(password, environmentCredentials.httpNodeBasicAuthPassword.value)) {
        let validatedUser = { username }
        foundUser.push(validatedUser)
      }
    } else {
      if (password === environmentCredentials.httpNodeBasicAuthPassword.value) {
        let validatedUser = { username }
        foundUser.push(validatedUser)
      }
    }
  }
  return foundUser
}

module.exports = function (req, res, next) {
  const credentials = auth(req)
  if (!credentials) {
    res.statusCode = 401
    res.setHeader('WWW-Authenticate', 'authorization required')
    res.end('Access denied')
  } else {
    let foundUser = getAuthenticatedUser(credentials.name, credentials.pass)
    if (foundUser.length > 0) {
      next()
    } else {
      res.statusCode = 401
      res.setHeader('WWW-Authenticate', 'authorization required')
      res.end('Access denied')
    }
  }
}
