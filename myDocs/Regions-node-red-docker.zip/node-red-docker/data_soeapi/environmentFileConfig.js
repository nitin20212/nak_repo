const fileProcessUtility = require('./fileProcessUtility')

const getDisableEditor = () => {
  let disableFlag = false
  let output = fileProcessUtility.getEnvironmentCredentialsArray().forEach(line => {
    let { lineName, lineEncryption, lineValue } = fileProcessUtility.extractLineVariable(line)
    if (lineName === 'disableNodeRedEditor') {
      lineValue = lineEncryption === 'Y' ? fileProcessUtility.decrypt(lineValue) : lineValue
      if (lineValue === 'true') {
        disableFlag = true
      }
    }
  })
  return disableFlag
}

module.exports = {
  getDisableEditor
}
